#include "BaseDatos.h"

BaseDatos::BaseDatos(/* args */)
{
}